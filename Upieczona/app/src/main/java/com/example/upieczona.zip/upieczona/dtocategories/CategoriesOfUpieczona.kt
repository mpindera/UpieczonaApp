package com.example.upieczona.dtocategories

class CategoriesOfUpieczona : ArrayList<CategoriesOfUpieczonaItemDto>()