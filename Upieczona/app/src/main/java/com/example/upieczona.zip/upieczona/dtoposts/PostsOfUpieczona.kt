package com.example.upieczona.dtoposts

class PostsOfUpieczona : ArrayList<
        PostsOfUpieczonaItemDto>()