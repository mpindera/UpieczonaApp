package com.example.upieczona.topappbar

enum class WidgetState {
  OPEN,
  CLOSED
}